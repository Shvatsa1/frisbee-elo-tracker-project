--
-- PostgreSQL database dump
--

\restrict u3dnEpafPDnKhGYfZgO13zFt2NV6a6XWEdQyV7Yb8RlOPbNWtbNBSB2tyhrYRAS

-- Dumped from database version 15.18 (Debian 15.18-1.pgdg13+1)
-- Dumped by pg_dump version 15.18 (Debian 15.18-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.player_statistics_cache DROP CONSTRAINT IF EXISTS player_statistics_cache_player_id_fkey;
ALTER TABLE IF EXISTS ONLY public.match_players DROP CONSTRAINT IF EXISTS match_players_player_id_fkey;
ALTER TABLE IF EXISTS ONLY public.match_players DROP CONSTRAINT IF EXISTS match_players_match_id_fkey;
ALTER TABLE IF EXISTS ONLY public.activity_feed DROP CONSTRAINT IF EXISTS activity_feed_player_id_fkey;
ALTER TABLE IF EXISTS ONLY public.activity_feed DROP CONSTRAINT IF EXISTS activity_feed_match_id_fkey;
ALTER TABLE IF EXISTS ONLY public.players DROP CONSTRAINT IF EXISTS players_player_name_key;
ALTER TABLE IF EXISTS ONLY public.players DROP CONSTRAINT IF EXISTS players_pkey;
ALTER TABLE IF EXISTS ONLY public.player_statistics_cache DROP CONSTRAINT IF EXISTS player_statistics_cache_pkey;
ALTER TABLE IF EXISTS ONLY public.matches DROP CONSTRAINT IF EXISTS matches_pkey;
ALTER TABLE IF EXISTS ONLY public.match_players DROP CONSTRAINT IF EXISTS match_players_pkey;
ALTER TABLE IF EXISTS ONLY public.activity_feed DROP CONSTRAINT IF EXISTS activity_feed_pkey;
ALTER TABLE IF EXISTS public.players ALTER COLUMN player_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.matches ALTER COLUMN match_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.match_players ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.activity_feed ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.players_player_id_seq;
DROP TABLE IF EXISTS public.players;
DROP TABLE IF EXISTS public.player_statistics_cache;
DROP SEQUENCE IF EXISTS public.matches_match_id_seq;
DROP TABLE IF EXISTS public.matches;
DROP SEQUENCE IF EXISTS public.match_players_id_seq;
DROP TABLE IF EXISTS public.match_players;
DROP SEQUENCE IF EXISTS public.activity_feed_id_seq;
DROP TABLE IF EXISTS public.activity_feed;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_feed; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity_feed (
    id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    player_id integer,
    match_id integer,
    description text NOT NULL,
    meta_data jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.activity_feed OWNER TO postgres;

--
-- Name: activity_feed_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activity_feed_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activity_feed_id_seq OWNER TO postgres;

--
-- Name: activity_feed_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activity_feed_id_seq OWNED BY public.activity_feed.id;


--
-- Name: match_players; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.match_players (
    id integer NOT NULL,
    match_id integer,
    player_id integer,
    team character varying(1) NOT NULL,
    elo_before double precision NOT NULL,
    elo_after double precision NOT NULL,
    elo_change double precision NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.match_players OWNER TO postgres;

--
-- Name: match_players_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.match_players_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.match_players_id_seq OWNER TO postgres;

--
-- Name: match_players_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.match_players_id_seq OWNED BY public.match_players.id;


--
-- Name: matches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.matches (
    match_id integer NOT NULL,
    match_date date NOT NULL,
    location character varying(255),
    team_a_score integer NOT NULL,
    team_b_score integer NOT NULL,
    winning_team character varying(1) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    expected_win_team_a double precision,
    expected_win_team_b double precision,
    team_a_avg_elo double precision,
    team_b_avg_elo double precision,
    team_a_name character varying(255) DEFAULT NULL::character varying,
    team_b_name character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public.matches OWNER TO postgres;

--
-- Name: matches_match_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.matches_match_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.matches_match_id_seq OWNER TO postgres;

--
-- Name: matches_match_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.matches_match_id_seq OWNED BY public.matches.match_id;


--
-- Name: player_statistics_cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.player_statistics_cache (
    player_id integer NOT NULL,
    win_percentage double precision DEFAULT 0,
    streak integer DEFAULT 0,
    clutch_score double precision DEFAULT 0,
    consistency_score double precision DEFAULT 0,
    activity_score double precision DEFAULT 0,
    last_elo_change double precision DEFAULT 0,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.player_statistics_cache OWNER TO postgres;

--
-- Name: players; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.players (
    player_id integer NOT NULL,
    player_name character varying(255) NOT NULL,
    current_elo double precision DEFAULT 1000,
    total_games integer DEFAULT 0,
    wins integer DEFAULT 0,
    losses integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.players OWNER TO postgres;

--
-- Name: players_player_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.players_player_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.players_player_id_seq OWNER TO postgres;

--
-- Name: players_player_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.players_player_id_seq OWNED BY public.players.player_id;


--
-- Name: activity_feed id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_feed ALTER COLUMN id SET DEFAULT nextval('public.activity_feed_id_seq'::regclass);


--
-- Name: match_players id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match_players ALTER COLUMN id SET DEFAULT nextval('public.match_players_id_seq'::regclass);


--
-- Name: matches match_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matches ALTER COLUMN match_id SET DEFAULT nextval('public.matches_match_id_seq'::regclass);


--
-- Name: players player_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.players ALTER COLUMN player_id SET DEFAULT nextval('public.players_player_id_seq'::regclass);


--
-- Data for Name: activity_feed; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity_feed (id, event_type, player_id, match_id, description, meta_data, created_at) FROM stdin;
1	NEW_PLAYER	9	\N	New player Pranav Teki joined Mumbai Ultimate!	{}	2026-06-04 05:17:51.789629
2	NEW_PLAYER	10	\N	New player Tarishi Jain joined Mumbai Ultimate!	{}	2026-06-04 05:17:58.309696
3	NEW_PLAYER	11	\N	New player Dr. Partha Patil joined Mumbai Ultimate!	{}	2026-06-04 05:18:08.492951
4	NEW_PLAYER	12	\N	New player Suryanshu Chauhan joined Mumbai Ultimate!	{}	2026-06-04 05:18:15.749174
5	NEW_PLAYER	13	\N	New player Antara joined Mumbai Ultimate!	{}	2026-06-04 05:18:23.254747
6	NEW_PLAYER	14	\N	New player Harsh Sehgal joined Mumbai Ultimate!	{}	2026-06-04 05:18:34.871801
7	NEW_PLAYER	15	\N	New player Ayush joined Mumbai Ultimate!	{}	2026-06-04 05:18:38.457507
8	NEW_PLAYER	16	\N	New player Mayur Parmar joined Mumbai Ultimate!	{}	2026-06-04 05:18:47.883428
9	NEW_PLAYER	17	\N	New player Prea Jain joined Mumbai Ultimate!	{}	2026-06-04 05:18:52.815726
10	NEW_PLAYER	18	\N	New player Kushal joined Mumbai Ultimate!	{}	2026-06-04 05:18:59.373775
11	NEW_PLAYER	19	\N	New player Niddhi joined Mumbai Ultimate!	{}	2026-06-04 05:19:02.963887
12	NEW_PLAYER	20	\N	New player Divy joined Mumbai Ultimate!	{}	2026-06-04 05:19:09.353535
13	NEW_PLAYER	21	\N	New player Chinmay joined Mumbai Ultimate!	{}	2026-06-04 05:19:14.375741
14	NEW_PLAYER	22	\N	New player Andre Gama joined Mumbai Ultimate!	{}	2026-06-04 05:19:21.508988
15	NEW_PLAYER	23	\N	New player Vignesh joined Mumbai Ultimate!	{}	2026-06-04 05:19:30.889907
16	NEW_PLAYER	24	\N	New player Plaksha joined Mumbai Ultimate!	{}	2026-06-04 05:19:36.139914
17	NEW_PLAYER	25	\N	New player Avi joined Mumbai Ultimate!	{}	2026-06-04 05:19:42.130437
18	NEW_PLAYER	26	\N	New player Sanskar joined Mumbai Ultimate!	{}	2026-06-04 05:19:47.71269
19	NEW_PLAYER	27	\N	New player Harshit Poddar joined Mumbai Ultimate!	{}	2026-06-04 05:19:57.750492
20	NEW_PLAYER	28	\N	New player Akhil joined Mumbai Ultimate!	{}	2026-06-04 05:20:02.981225
21	NEW_PLAYER	29	\N	New player Anmol Samat joined Mumbai Ultimate!	{}	2026-06-04 05:20:08.525407
22	NEW_PLAYER	30	\N	New player Shrestha joined Mumbai Ultimate!	{}	2026-06-04 05:20:14.559889
23	NEW_PLAYER	31	\N	New player Aryan joined Mumbai Ultimate!	{}	2026-06-04 05:20:19.281156
24	NEW_PLAYER	32	\N	New player Maaz joined Mumbai Ultimate!	{}	2026-06-04 05:20:22.261901
25	NEW_PLAYER	33	\N	New player Divyansh joined Mumbai Ultimate!	{}	2026-06-04 05:20:26.542321
26	NEW_PLAYER	34	\N	New player Zubin joined Mumbai Ultimate!	{}	2026-06-04 05:20:29.920174
27	NEW_PLAYER	35	\N	New player Ahaan C joined Mumbai Ultimate!	{}	2026-06-04 05:20:35.35171
28	NEW_PLAYER	36	\N	New player Stefan joined Mumbai Ultimate!	{}	2026-06-04 05:20:38.990933
29	NEW_PLAYER	37	\N	New player Karan Arora joined Mumbai Ultimate!	{}	2026-06-04 05:20:44.029863
30	NEW_PLAYER	38	\N	New player Steffi K joined Mumbai Ultimate!	{}	2026-06-04 05:20:48.74997
31	NEW_PLAYER	39	\N	New player Vikram Barada joined Mumbai Ultimate!	{}	2026-06-04 05:20:54.962604
32	NEW_PLAYER	40	\N	New player Eswar Lade joined Mumbai Ultimate!	{}	2026-06-04 05:21:00.921284
33	NEW_PLAYER	41	\N	New player Sourabh Meena joined Mumbai Ultimate!	{}	2026-06-04 05:21:05.208933
34	NEW_PLAYER	42	\N	New player Shishir joined Mumbai Ultimate!	{}	2026-06-04 05:21:10.930653
35	NEW_PLAYER	43	\N	New player Virag joined Mumbai Ultimate!	{}	2026-06-04 05:21:23.037946
36	NEW_PLAYER	44	\N	New player Maan joined Mumbai Ultimate!	{}	2026-06-04 05:21:26.881965
37	NEW_PLAYER	45	\N	New player Shantanu Vatsa joined Mumbai Ultimate!	{}	2026-06-04 05:21:39.956399
38	NEW_PLAYER	46	\N	New player Vaibhav joined Mumbai Ultimate!	{}	2026-06-04 05:22:34.888964
39	NEW_PLAYER	47	\N	New player Saad joined Mumbai Ultimate!	{}	2026-06-04 05:22:41.231165
40	MATCH_LOGGED	\N	1	Team B won a match!	{"elo_swing": 20}	2026-06-04 06:35:12.475959
41	MATCH_LOGGED	\N	2	Team D won a match!	{"elo_swing": 20}	2026-06-04 06:35:29.946227
42	MATCH_LOGGED	\N	3	Team D won a match!	{"elo_swing": 18}	2026-06-04 06:35:49.016294
43	MATCH_LOGGED	\N	4	Team A won a match!	{"elo_swing": 22}	2026-06-04 06:36:09.14364
44	MATCH_LOGGED	\N	5	Team C won a match!	{"elo_swing": 22}	2026-06-04 06:36:32.202215
45	MATCH_LOGGED	\N	6	Team D won a match!	{"elo_swing": 18}	2026-06-04 06:36:46.675778
46	NEW_PLAYER	48	\N	New player Shitanshu joined Mumbai Ultimate!	{}	2026-06-04 19:46:10.305948
47	NEW_PLAYER	49	\N	New player Soham Dave joined Mumbai Ultimate!	{}	2026-06-04 19:47:04.51481
48	NEW_PLAYER	50	\N	New player Kripa joined Mumbai Ultimate!	{}	2026-06-04 19:47:41.405401
49	NEW_PLAYER	51	\N	New player Chaitanya joined Mumbai Ultimate!	{}	2026-06-04 19:48:03.230179
50	NEW_PLAYER	52	\N	New player Binson joined Mumbai Ultimate!	{}	2026-06-04 19:48:21.082831
\.


--
-- Data for Name: match_players; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.match_players (id, match_id, player_id, team, elo_before, elo_after, elo_change, created_at) FROM stdin;
1	1	17	A	1000	1020	20	2026-06-04 06:35:12.23418
2	1	46	A	1000	1020	20	2026-06-04 06:35:12.23418
3	1	19	A	1000	1020	20	2026-06-04 06:35:12.23418
4	1	22	A	1000	1020	20	2026-06-04 06:35:12.23418
5	1	18	A	1000	1020	20	2026-06-04 06:35:12.23418
6	1	16	A	1000	1020	20	2026-06-04 06:35:12.23418
7	1	21	A	1000	1020	20	2026-06-04 06:35:12.23418
8	1	29	B	1000	980	-20	2026-06-04 06:35:12.23418
9	1	28	B	1000	980	-20	2026-06-04 06:35:12.23418
10	1	26	B	1000	980	-20	2026-06-04 06:35:12.23418
11	1	23	B	1000	980	-20	2026-06-04 06:35:12.23418
12	1	27	B	1000	980	-20	2026-06-04 06:35:12.23418
13	1	24	B	1000	980	-20	2026-06-04 06:35:12.23418
14	1	25	B	1000	980	-20	2026-06-04 06:35:12.23418
15	2	11	A	1000	980	-20	2026-06-04 06:35:29.88273
16	2	14	A	1000	980	-20	2026-06-04 06:35:29.88273
17	2	10	A	1000	980	-20	2026-06-04 06:35:29.88273
18	2	15	A	1000	980	-20	2026-06-04 06:35:29.88273
19	2	37	A	1000	980	-20	2026-06-04 06:35:29.88273
20	2	13	A	1000	980	-20	2026-06-04 06:35:29.88273
21	2	9	A	1000	980	-20	2026-06-04 06:35:29.88273
22	2	31	B	1000	1020	20	2026-06-04 06:35:29.88273
23	2	34	B	1000	1020	20	2026-06-04 06:35:29.88273
24	2	47	B	1000	1020	20	2026-06-04 06:35:29.88273
25	2	36	B	1000	1020	20	2026-06-04 06:35:29.88273
26	2	12	B	1000	1020	20	2026-06-04 06:35:29.88273
27	2	30	B	1000	1020	20	2026-06-04 06:35:29.88273
28	2	33	B	1000	1020	20	2026-06-04 06:35:29.88273
29	2	35	B	1000	1020	20	2026-06-04 06:35:29.88273
30	3	29	A	980	962.2924653504917	-17.70753464950829	2026-06-04 06:35:48.954522
31	3	28	A	980	962.2924653504917	-17.70753464950829	2026-06-04 06:35:48.954522
32	3	26	A	980	962.2924653504917	-17.70753464950829	2026-06-04 06:35:48.954522
33	3	23	A	980	962.2924653504917	-17.70753464950829	2026-06-04 06:35:48.954522
34	3	27	A	980	962.2924653504917	-17.70753464950829	2026-06-04 06:35:48.954522
35	3	24	A	980	962.2924653504917	-17.70753464950829	2026-06-04 06:35:48.954522
36	3	25	A	980	962.2924653504917	-17.70753464950829	2026-06-04 06:35:48.954522
37	3	31	B	1020	1037.7075346495083	17.70753464950829	2026-06-04 06:35:48.954522
38	3	34	B	1020	1037.7075346495083	17.70753464950829	2026-06-04 06:35:48.954522
39	3	47	B	1020	1037.7075346495083	17.70753464950829	2026-06-04 06:35:48.954522
40	3	36	B	1020	1037.7075346495083	17.70753464950829	2026-06-04 06:35:48.954522
41	3	12	B	1020	1037.7075346495083	17.70753464950829	2026-06-04 06:35:48.954522
42	3	30	B	1020	1037.7075346495083	17.70753464950829	2026-06-04 06:35:48.954522
43	3	33	B	1020	1037.7075346495083	17.70753464950829	2026-06-04 06:35:48.954522
44	3	35	B	1020	1037.7075346495083	17.70753464950829	2026-06-04 06:35:48.954522
45	4	11	A	980	1002.2924653504917	22.29246535049171	2026-06-04 06:36:09.081934
46	4	14	A	980	1002.2924653504917	22.29246535049171	2026-06-04 06:36:09.081934
47	4	10	A	980	1002.2924653504917	22.29246535049171	2026-06-04 06:36:09.081934
48	4	15	A	980	1002.2924653504917	22.29246535049171	2026-06-04 06:36:09.081934
49	4	37	A	980	1002.2924653504917	22.29246535049171	2026-06-04 06:36:09.081934
50	4	13	A	980	1002.2924653504917	22.29246535049171	2026-06-04 06:36:09.081934
51	4	9	A	980	1002.2924653504917	22.29246535049171	2026-06-04 06:36:09.081934
52	4	17	B	1020	997.7075346495083	-22.29246535049171	2026-06-04 06:36:09.081934
53	4	46	B	1020	997.7075346495083	-22.29246535049171	2026-06-04 06:36:09.081934
54	4	19	B	1020	997.7075346495083	-22.29246535049171	2026-06-04 06:36:09.081934
55	4	22	B	1020	997.7075346495083	-22.29246535049171	2026-06-04 06:36:09.081934
56	4	18	B	1020	997.7075346495083	-22.29246535049171	2026-06-04 06:36:09.081934
57	4	16	B	1020	997.7075346495083	-22.29246535049171	2026-06-04 06:36:09.081934
58	4	21	B	1020	997.7075346495083	-22.29246535049171	2026-06-04 06:36:09.081934
59	5	11	A	1002.2924653504917	980	-22.29246535049171	2026-06-04 06:36:32.147854
60	5	14	A	1002.2924653504917	980	-22.29246535049171	2026-06-04 06:36:32.147854
61	5	10	A	1002.2924653504917	980	-22.29246535049171	2026-06-04 06:36:32.147854
62	5	15	A	1002.2924653504917	980	-22.29246535049171	2026-06-04 06:36:32.147854
63	5	37	A	1002.2924653504917	980	-22.29246535049171	2026-06-04 06:36:32.147854
64	5	13	A	1002.2924653504917	980	-22.29246535049171	2026-06-04 06:36:32.147854
65	5	9	A	1002.2924653504917	980	-22.29246535049171	2026-06-04 06:36:32.147854
66	5	29	B	962.2924653504917	984.5849307009835	22.29246535049171	2026-06-04 06:36:32.147854
67	5	28	B	962.2924653504917	984.5849307009835	22.29246535049171	2026-06-04 06:36:32.147854
68	5	26	B	962.2924653504917	984.5849307009835	22.29246535049171	2026-06-04 06:36:32.147854
69	5	23	B	962.2924653504917	984.5849307009835	22.29246535049171	2026-06-04 06:36:32.147854
70	5	27	B	962.2924653504917	984.5849307009835	22.29246535049171	2026-06-04 06:36:32.147854
71	5	24	B	962.2924653504917	984.5849307009835	22.29246535049171	2026-06-04 06:36:32.147854
72	5	25	B	962.2924653504917	984.5849307009835	22.29246535049171	2026-06-04 06:36:32.147854
73	6	17	A	997.7075346495083	980	-17.707534649508297	2026-06-04 06:36:46.598883
74	6	46	A	997.7075346495083	980	-17.707534649508297	2026-06-04 06:36:46.598883
75	6	19	A	997.7075346495083	980	-17.707534649508297	2026-06-04 06:36:46.598883
76	6	22	A	997.7075346495083	980	-17.707534649508297	2026-06-04 06:36:46.598883
77	6	18	A	997.7075346495083	980	-17.707534649508297	2026-06-04 06:36:46.598883
78	6	16	A	997.7075346495083	980	-17.707534649508297	2026-06-04 06:36:46.598883
79	6	21	A	997.7075346495083	980	-17.707534649508297	2026-06-04 06:36:46.598883
80	6	31	B	1037.7075346495083	1055.4150692990165	17.707534649508293	2026-06-04 06:36:46.598883
81	6	34	B	1037.7075346495083	1055.4150692990165	17.707534649508293	2026-06-04 06:36:46.598883
82	6	47	B	1037.7075346495083	1055.4150692990165	17.707534649508293	2026-06-04 06:36:46.598883
83	6	36	B	1037.7075346495083	1055.4150692990165	17.707534649508293	2026-06-04 06:36:46.598883
84	6	12	B	1037.7075346495083	1055.4150692990165	17.707534649508293	2026-06-04 06:36:46.598883
85	6	30	B	1037.7075346495083	1055.4150692990165	17.707534649508293	2026-06-04 06:36:46.598883
86	6	33	B	1037.7075346495083	1055.4150692990165	17.707534649508293	2026-06-04 06:36:46.598883
87	6	35	B	1037.7075346495083	1055.4150692990165	17.707534649508293	2026-06-04 06:36:46.598883
\.


--
-- Data for Name: matches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.matches (match_id, match_date, location, team_a_score, team_b_score, winning_team, created_at, expected_win_team_a, expected_win_team_b, team_a_avg_elo, team_b_avg_elo, team_a_name, team_b_name) FROM stdin;
1	2026-06-04	Pickup Wednesday	9	7	A	2026-06-04 06:35:12.23418	0.5	0.5	1000	1000	Team B	Team C
2	2026-06-04	Pickup Wednesday	7	8	B	2026-06-04 06:35:29.88273	0.5	0.5	1000	1000	Team A	Team D
3	2026-06-04	Pickup Wednesday	6	8	B	2026-06-04 06:35:48.954522	0.44268836623770724	0.5573116337622928	980	1020	Team C	Team D
4	2026-06-04	Pickup Wednesday	12	7	A	2026-06-04 06:36:09.081934	0.44268836623770724	0.5573116337622928	980	1020	Team A	Team B
5	2026-06-04	Pickup Wednesday	6	7	B	2026-06-04 06:36:32.147854	0.5573116337622928	0.44268836623770724	1002.2924653504916	962.2924653504916	Team A	Team C
6	2026-06-04	Pickup Wednesday	5	11	B	2026-06-04 06:36:46.598883	0.4426883662377074	0.5573116337622926	997.7075346495084	1037.7075346495083	Team B	Team D
\.


--
-- Data for Name: player_statistics_cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.player_statistics_cache (player_id, win_percentage, streak, clutch_score, consistency_score, activity_score, last_elo_change, updated_at) FROM stdin;
2	0	0	0	0	0	0	2026-06-04 06:36:46.694541
3	0	0	0	0	0	0	2026-06-04 06:36:46.698499
4	0	0	0	0	0	0	2026-06-04 06:36:46.702321
5	0	0	0	0	0	0	2026-06-04 06:36:46.705865
6	0	0	0	0	0	0	2026-06-04 06:36:46.710528
7	0	0	0	0	0	0	2026-06-04 06:36:46.716286
8	0	0	0	0	0	0	2026-06-04 06:36:46.721426
17	33.33333333333333	-2	0	0	0	-17.707534649508297	2026-06-04 06:36:46.821934
20	0	0	0	0	0	0	2026-06-04 06:36:46.727289
32	0	0	0	0	0	0	2026-06-04 06:36:46.734739
38	0	0	0	0	0	0	2026-06-04 06:36:46.738193
39	0	0	0	0	0	0	2026-06-04 06:36:46.741112
40	0	0	0	0	0	0	2026-06-04 06:36:46.743927
41	0	0	0	0	0	0	2026-06-04 06:36:46.747093
46	33.33333333333333	-2	0	0	0	-17.707534649508297	2026-06-04 06:36:46.825217
19	33.33333333333333	-2	0	0	0	-17.707534649508297	2026-06-04 06:36:46.831381
22	33.33333333333333	-2	0	0	0	-17.707534649508297	2026-06-04 06:36:46.834809
18	33.33333333333333	-2	0	0	0	-17.707534649508297	2026-06-04 06:36:46.837645
16	33.33333333333333	-2	0	0	0	-17.707534649508297	2026-06-04 06:36:46.841992
21	33.33333333333333	-2	0	0	0	-17.707534649508297	2026-06-04 06:36:46.848908
42	0	0	0	0	0	0	2026-06-04 06:36:46.750335
43	0	0	0	0	0	0	2026-06-04 06:36:46.756028
44	0	0	0	0	0	0	2026-06-04 06:36:46.759879
45	0	0	0	0	0	0	2026-06-04 06:36:46.763592
11	33.33333333333333	-1	0	0	0	-22.29246535049171	2026-06-04 06:36:46.769054
14	33.33333333333333	-1	0	0	0	-22.29246535049171	2026-06-04 06:36:46.772408
10	33.33333333333333	-1	0	0	0	-22.29246535049171	2026-06-04 06:36:46.775759
15	33.33333333333333	-1	0	0	0	-22.29246535049171	2026-06-04 06:36:46.779417
37	33.33333333333333	-1	0	0	0	-22.29246535049171	2026-06-04 06:36:46.782406
13	33.33333333333333	-1	0	0	0	-22.29246535049171	2026-06-04 06:36:46.785589
9	33.33333333333333	-1	0	0	0	-22.29246535049171	2026-06-04 06:36:46.78861
29	33.33333333333333	1	0	0	0	22.29246535049171	2026-06-04 06:36:46.792049
28	33.33333333333333	1	0	0	0	22.29246535049171	2026-06-04 06:36:46.796197
26	33.33333333333333	1	0	0	0	22.29246535049171	2026-06-04 06:36:46.800007
23	33.33333333333333	1	0	0	0	22.29246535049171	2026-06-04 06:36:46.803945
27	33.33333333333333	1	0	0	0	22.29246535049171	2026-06-04 06:36:46.809549
24	33.33333333333333	1	0	0	0	22.29246535049171	2026-06-04 06:36:46.813886
25	33.33333333333333	1	0	0	0	22.29246535049171	2026-06-04 06:36:46.817145
31	100	3	0	0	0	17.707534649508293	2026-06-04 06:36:46.851899
34	100	3	0	0	0	17.707534649508293	2026-06-04 06:36:46.855414
47	100	3	0	0	0	17.707534649508293	2026-06-04 06:36:46.860632
36	100	3	0	0	0	17.707534649508293	2026-06-04 06:36:46.865976
12	100	3	0	0	0	17.707534649508293	2026-06-04 06:36:46.869211
30	100	3	0	0	0	17.707534649508293	2026-06-04 06:36:46.872312
33	100	3	0	0	0	17.707534649508293	2026-06-04 06:36:46.87713
35	100	3	0	0	0	17.707534649508293	2026-06-04 06:36:46.882016
1	0	0	0	0	0	0	2026-06-04 06:36:46.69113
\.


--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.players (player_id, player_name, current_elo, total_games, wins, losses, created_at) FROM stdin;
1	Alice	1200	16	10	6	2026-06-03 15:40:54.351774
2	Bob	980	5	2	3	2026-06-03 15:40:54.351774
3	Charlie	1050	10	5	5	2026-06-03 15:40:54.351774
4	David	1000	0	0	0	2026-06-03 15:40:54.351774
5	Eve	1100	20	12	8	2026-06-03 15:40:54.351774
6	Frank	950	8	3	5	2026-06-03 15:40:54.351774
7	Grace	1300	30	20	10	2026-06-03 15:40:54.351774
8	Heidi	1000	0	0	0	2026-06-03 15:40:54.351774
20	Divy	1000	0	0	0	2026-06-04 05:19:09.351436
32	Maaz	1000	0	0	0	2026-06-04 05:20:22.258376
38	Steffi K	1000	0	0	0	2026-06-04 05:20:48.747971
39	Vikram Barada	1000	0	0	0	2026-06-04 05:20:54.952679
40	Eswar Lade	1000	0	0	0	2026-06-04 05:21:00.918072
41	Sourabh Meena	1000	0	0	0	2026-06-04 05:21:05.206329
42	Shishir	1000	0	0	0	2026-06-04 05:21:10.928518
43	Virag	1000	0	0	0	2026-06-04 05:21:23.033115
44	Maan	1000	0	0	0	2026-06-04 05:21:26.878093
45	Shantanu Vatsa	1000	0	0	0	2026-06-04 05:21:39.952893
52	Binson	1000	0	0	0	2026-06-04 19:48:21.078687
11	Dr. Partha Patil	980	3	1	2	2026-06-04 05:18:08.488719
14	Harsh Sehgal	980	3	1	2	2026-06-04 05:18:34.868307
10	Tarishi Jain	980	3	1	2	2026-06-04 05:17:58.306463
15	Ayush	980	3	1	2	2026-06-04 05:18:38.451622
37	Karan Arora	980	3	1	2	2026-06-04 05:20:44.027993
13	Antara	980	3	1	2	2026-06-04 05:18:23.251546
9	Pranav Teki	980	3	1	2	2026-06-04 05:17:51.776741
29	Anmol Samat	984.5849307009835	3	1	2	2026-06-04 05:20:08.517126
28	Akhil	984.5849307009835	3	1	2	2026-06-04 05:20:02.978228
26	Sanskar	984.5849307009835	3	1	2	2026-06-04 05:19:47.709081
23	Vignesh	984.5849307009835	3	1	2	2026-06-04 05:19:30.888013
27	Harshit Poddar	984.5849307009835	3	1	2	2026-06-04 05:19:57.748362
24	Plaksha	984.5849307009835	3	1	2	2026-06-04 05:19:36.137734
25	Avi	984.5849307009835	3	1	2	2026-06-04 05:19:42.127936
17	Prea Jain	980	3	1	2	2026-06-04 05:18:52.813862
46	Vaibhav	980	3	1	2	2026-06-04 05:22:34.885528
19	Niddhi	980	3	1	2	2026-06-04 05:19:02.961011
22	Andre Gama	980	3	1	2	2026-06-04 05:19:21.506792
18	Kushal	980	3	1	2	2026-06-04 05:18:59.370836
16	Mayur Parmar	980	3	1	2	2026-06-04 05:18:47.881098
21	Chinmay	980	3	1	2	2026-06-04 05:19:14.371969
31	Aryan	1055.4150692990165	3	3	0	2026-06-04 05:20:19.278136
34	Zubin	1055.4150692990165	3	3	0	2026-06-04 05:20:29.918298
47	Saad	1055.4150692990165	3	3	0	2026-06-04 05:22:41.228089
36	Stefan	1055.4150692990165	3	3	0	2026-06-04 05:20:38.98833
12	Suryanshu Chauhan	1055.4150692990165	3	3	0	2026-06-04 05:18:15.746984
30	Shrestha	1055.4150692990165	3	3	0	2026-06-04 05:20:14.557856
33	Divyansh	1055.4150692990165	3	3	0	2026-06-04 05:20:26.538679
35	Ahaan C	1055.4150692990165	3	3	0	2026-06-04 05:20:35.348758
48	Shitanshu	1000	0	0	0	2026-06-04 19:46:10.297658
49	Soham Dave	1000	0	0	0	2026-06-04 19:47:04.51145
50	Kripa	1000	0	0	0	2026-06-04 19:47:41.401757
51	Chaitanya	1000	0	0	0	2026-06-04 19:48:03.226414
\.


--
-- Name: activity_feed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activity_feed_id_seq', 50, true);


--
-- Name: match_players_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.match_players_id_seq', 87, true);


--
-- Name: matches_match_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.matches_match_id_seq', 6, true);


--
-- Name: players_player_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.players_player_id_seq', 52, true);


--
-- Name: activity_feed activity_feed_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_feed
    ADD CONSTRAINT activity_feed_pkey PRIMARY KEY (id);


--
-- Name: match_players match_players_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match_players
    ADD CONSTRAINT match_players_pkey PRIMARY KEY (id);


--
-- Name: matches matches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_pkey PRIMARY KEY (match_id);


--
-- Name: player_statistics_cache player_statistics_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_statistics_cache
    ADD CONSTRAINT player_statistics_cache_pkey PRIMARY KEY (player_id);


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (player_id);


--
-- Name: players players_player_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_player_name_key UNIQUE (player_name);


--
-- Name: activity_feed activity_feed_match_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_feed
    ADD CONSTRAINT activity_feed_match_id_fkey FOREIGN KEY (match_id) REFERENCES public.matches(match_id) ON DELETE SET NULL;


--
-- Name: activity_feed activity_feed_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_feed
    ADD CONSTRAINT activity_feed_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(player_id) ON DELETE SET NULL;


--
-- Name: match_players match_players_match_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match_players
    ADD CONSTRAINT match_players_match_id_fkey FOREIGN KEY (match_id) REFERENCES public.matches(match_id) ON DELETE CASCADE;


--
-- Name: match_players match_players_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.match_players
    ADD CONSTRAINT match_players_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(player_id) ON DELETE CASCADE;


--
-- Name: player_statistics_cache player_statistics_cache_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_statistics_cache
    ADD CONSTRAINT player_statistics_cache_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(player_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict u3dnEpafPDnKhGYfZgO13zFt2NV6a6XWEdQyV7Yb8RlOPbNWtbNBSB2tyhrYRAS

